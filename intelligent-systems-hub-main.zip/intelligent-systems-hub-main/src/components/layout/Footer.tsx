import { Link } from "react-router-dom";
import { Bot, Mail, MapPin, Github, Linkedin, Twitter } from "lucide-react";

const Footer = () => {
  return (
    <footer className="bg-primary text-primary-foreground">
      <div className="container-narrow py-12 md:py-16">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Logo & Description */}
          <div className="md:col-span-2">
            <Link to="/" className="flex items-center gap-2 mb-4">
              <div className="w-10 h-10 rounded-lg bg-accent flex items-center justify-center">
                <Bot className="w-6 h-6 text-accent-foreground" />
              </div>
              <div>
                <span className="font-serif font-bold text-lg">RISR</span>
                <span className="text-xs text-primary-foreground/70 block -mt-1">Research Group</span>
              </div>
            </Link>
            <p className="text-primary-foreground/80 text-sm leading-relaxed max-w-md">
              Robotics and Intelligent Systems Research Group - Advancing the frontiers of 
              autonomous systems, machine learning, and human-robot interaction.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-serif font-semibold text-lg mb-4">Quick Links</h4>
            <ul className="space-y-2 text-sm">
              <li><Link to="/research" className="text-primary-foreground/80 hover:text-accent transition-colors">Research</Link></li>
              <li><Link to="/members" className="text-primary-foreground/80 hover:text-accent transition-colors">Team</Link></li>
              <li><Link to="/opportunities" className="text-primary-foreground/80 hover:text-accent transition-colors">Opportunities</Link></li>
              <li><Link to="/grants" className="text-primary-foreground/80 hover:text-accent transition-colors">Grants</Link></li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="font-serif font-semibold text-lg mb-4">Contact</h4>
            <ul className="space-y-3 text-sm">
              <li className="flex items-center gap-2 text-primary-foreground/80">
                <Mail className="w-4 h-4" />
                risr@university.edu
              </li>
              <li className="flex items-start gap-2 text-primary-foreground/80">
                <MapPin className="w-4 h-4 mt-0.5" />
                <span>Engineering Building, Room 301<br />University Campus</span>
              </li>
            </ul>
            <div className="flex gap-4 mt-4">
              <a href="https://github.com" target="_blank" rel="noopener noreferrer" className="text-primary-foreground/80 hover:text-accent transition-colors">
                <Github className="w-5 h-5" />
              </a>
              <a href="https://linkedin.com" target="_blank" rel="noopener noreferrer" className="text-primary-foreground/80 hover:text-accent transition-colors">
                <Linkedin className="w-5 h-5" />
              </a>
              <a href="https://twitter.com" target="_blank" rel="noopener noreferrer" className="text-primary-foreground/80 hover:text-accent transition-colors">
                <Twitter className="w-5 h-5" />
              </a>
            </div>
          </div>
        </div>

        <div className="border-t border-primary-foreground/20 mt-10 pt-6 text-center text-sm text-primary-foreground/60">
          <p>© {new Date().getFullYear()} Robotics and Intelligent Systems Research Group. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
