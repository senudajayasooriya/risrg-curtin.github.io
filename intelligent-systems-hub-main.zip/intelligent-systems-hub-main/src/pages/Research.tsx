import { useState } from "react";
import Layout from "@/components/layout/Layout";
import { ExternalLink, Github, FileText } from "lucide-react";

interface ResearchItem {
  year: number;
  title: string;
  authors: string;
  abstract: string;
  funding: string;
  venue: string;
  links: {
    paper?: string;
    github?: string;
    dataset?: string;
  };
}

const researchData: ResearchItem[] = [
  {
    year: 2026,
    title: "Adaptive Grasping with Multi-Modal Tactile Feedback for Delicate Object Manipulation",
    authors: "Dr. Sarah Chen, James Wilson, Dr. Michael Rodriguez",
    abstract: "This paper presents a novel approach to robotic grasping using multi-modal tactile sensors combined with deep reinforcement learning for handling fragile objects with varying properties.",
    funding: "NSF Award #2345678",
    venue: "IEEE Robotics and Automation Letters",
    links: { paper: "#", github: "#" },
  },
  {
    year: 2026,
    title: "Real-Time Semantic SLAM for Indoor Navigation in Dynamic Environments",
    authors: "Emily Zhang, Dr. Sarah Chen, Alex Kumar",
    abstract: "We propose a semantic SLAM framework that enables robust navigation in environments with moving obstacles and changing layouts using transformer-based scene understanding.",
    funding: "DARPA Grant",
    venue: "ICRA 2026",
    links: { paper: "#", github: "#", dataset: "#" },
  },
  {
    year: 2025,
    title: "Human-Robot Collaborative Assembly: A Shared Autonomy Framework",
    authors: "Dr. Michael Rodriguez, Lisa Park, James Wilson",
    abstract: "This work introduces a shared autonomy framework for human-robot collaboration in manufacturing, enabling seamless task handoff and adaptive assistance levels.",
    funding: "NSF Award #2123456",
    venue: "IEEE International Conference on Robotics and Automation (ICRA)",
    links: { paper: "#" },
  },
  {
    year: 2025,
    title: "Efficient Policy Transfer for Multi-Robot Coordination",
    authors: "Alex Kumar, Dr. Sarah Chen",
    abstract: "We present a method for transferring learned policies between different multi-robot systems, significantly reducing training time for new robot configurations.",
    funding: "Industry Partner: Boston Dynamics",
    venue: "Conference on Robot Learning (CoRL)",
    links: { paper: "#", github: "#" },
  },
  {
    year: 2025,
    title: "Self-Supervised Learning for Robotic Manipulation from Demonstration",
    authors: "James Wilson, Emily Zhang, Dr. Michael Rodriguez",
    abstract: "A self-supervised approach that enables robots to learn complex manipulation tasks from a small number of human demonstrations.",
    funding: "NSF Award #2123456",
    venue: "NeurIPS 2025",
    links: { paper: "#", github: "#", dataset: "#" },
  },
  {
    year: 2024,
    title: "Robust Visual Odometry for Agricultural Robots",
    authors: "Lisa Park, Dr. Sarah Chen",
    abstract: "Developing robust visual odometry systems for outdoor agricultural robots operating in challenging lighting and terrain conditions.",
    funding: "USDA Grant",
    venue: "IEEE/RSJ International Conference on Intelligent Robots and Systems (IROS)",
    links: { paper: "#" },
  },
  {
    year: 2024,
    title: "Energy-Efficient Motion Planning for Mobile Manipulation",
    authors: "Dr. Michael Rodriguez, Alex Kumar",
    abstract: "Novel motion planning algorithms that optimize for energy consumption while maintaining task performance in mobile manipulation scenarios.",
    funding: "DOE Grant",
    venue: "Robotics: Science and Systems (RSS)",
    links: { paper: "#", github: "#" },
  },
];

const years = [...new Set(researchData.map(item => item.year))].sort((a, b) => b - a);

const Research = () => {
  const [selectedYear, setSelectedYear] = useState<number | "all">("all");

  const filteredResearch = selectedYear === "all" 
    ? researchData 
    : researchData.filter(item => item.year === selectedYear);

  return (
    <Layout>
      {/* Header */}
      <section className="bg-primary py-16 md:py-20">
        <div className="container-narrow">
          <h1 className="font-serif text-4xl md:text-5xl font-bold text-primary-foreground mb-4 animate-fade-up">
            Research
          </h1>
          <p className="text-primary-foreground/80 text-lg max-w-2xl animate-fade-up delay-100">
            Explore our publications and research projects organized by year. 
            Our work spans robotics, machine learning, and intelligent systems.
          </p>
        </div>
      </section>

      {/* Filter & Content */}
      <section className="section-padding">
        <div className="container-narrow">
          {/* Year Filter */}
          <div className="flex flex-wrap gap-3 mb-10">
            <button
              onClick={() => setSelectedYear("all")}
              className={`filter-btn ${selectedYear === "all" ? "filter-btn-active" : "filter-btn-inactive"}`}
            >
              All Years
            </button>
            {years.map(year => (
              <button
                key={year}
                onClick={() => setSelectedYear(year)}
                className={`filter-btn ${selectedYear === year ? "filter-btn-active" : "filter-btn-inactive"}`}
              >
                {year}
              </button>
            ))}
          </div>

          {/* Research Items */}
          <div className="space-y-6">
            {filteredResearch.map((item, index) => (
              <article 
                key={index}
                className="card-academic animate-fade-up"
                style={{ animationDelay: `${index * 50}ms` }}
              >
                <div className="flex flex-wrap items-center gap-3 mb-3">
                  <span className="badge-research">{item.year}</span>
                  <span className="text-sm text-muted-foreground">{item.venue}</span>
                </div>
                <h2 className="font-serif text-xl font-semibold text-foreground mb-2">
                  {item.title}
                </h2>
                <p className="text-accent text-sm mb-3">{item.authors}</p>
                <p className="text-muted-foreground text-sm mb-4 leading-relaxed">
                  {item.abstract}
                </p>
                <div className="flex flex-wrap items-center justify-between gap-4">
                  <span className="text-xs text-muted-foreground bg-muted px-3 py-1 rounded-full">
                    {item.funding}
                  </span>
                  <div className="flex gap-3">
                    {item.links.paper && (
                      <a href={item.links.paper} className="flex items-center gap-1 text-sm text-accent hover:underline">
                        <FileText className="w-4 h-4" /> Paper
                      </a>
                    )}
                    {item.links.github && (
                      <a href={item.links.github} className="flex items-center gap-1 text-sm text-accent hover:underline">
                        <Github className="w-4 h-4" /> Code
                      </a>
                    )}
                    {item.links.dataset && (
                      <a href={item.links.dataset} className="flex items-center gap-1 text-sm text-accent hover:underline">
                        <ExternalLink className="w-4 h-4" /> Dataset
                      </a>
                    )}
                  </div>
                </div>
              </article>
            ))}
          </div>

          {filteredResearch.length === 0 && (
            <div className="text-center py-12 text-muted-foreground">
              No research found for the selected year.
            </div>
          )}
        </div>
      </section>
    </Layout>
  );
};

export default Research;
