import Layout from "@/components/layout/Layout";
import { Button } from "@/components/ui/button";
import { Calendar, Clock, Users, GraduationCap, Mail, ArrowRight } from "lucide-react";

interface Opportunity {
  title: string;
  type: "current" | "upcoming";
  projectType: "PhD" | "MSc" | "Undergrad" | "Postdoc";
  description: string;
  skills: string[];
  eligibility: string;
  supervisor: string;
  deadline?: string;
  startDate?: string;
  email: string;
}

const opportunities: Opportunity[] = [
  {
    title: "PhD Position: Deep Learning for Robotic Manipulation",
    type: "current",
    projectType: "PhD",
    description: "We are seeking a motivated PhD student to work on deep learning approaches for dexterous manipulation. The project involves developing novel neural network architectures for learning manipulation skills from demonstration and self-supervised exploration.",
    skills: ["Python/PyTorch", "Robotics (ROS)", "Deep Learning", "Computer Vision"],
    eligibility: "MSc in CS, Robotics, or related field. Strong programming skills required.",
    supervisor: "Dr. Sarah Chen",
    deadline: "February 28, 2026",
    email: "schen@university.edu",
  },
  {
    title: "MSc Thesis: Multi-Robot Coordination in Warehouses",
    type: "current",
    projectType: "MSc",
    description: "Research project focusing on coordination algorithms for autonomous mobile robots in warehouse environments. Involves simulation development and real robot experiments.",
    skills: ["Python", "Multi-Agent Systems", "Path Planning", "Simulation"],
    eligibility: "Enrolled MSc student in CS/Robotics. Interest in multi-agent systems.",
    supervisor: "Dr. Michael Rodriguez",
    deadline: "March 15, 2026",
    email: "mrodriguez@university.edu",
  },
  {
    title: "Undergraduate Research: ROS2 Integration for Sensor Suite",
    type: "current",
    projectType: "Undergrad",
    description: "Summer research opportunity to help integrate various sensors (LiDAR, cameras, IMU) into our ROS2-based robot platform. Great opportunity to gain hands-on robotics experience.",
    skills: ["C++/Python", "Linux", "Basic ROS knowledge (preferred)"],
    eligibility: "Undergraduate in CS/EE/ME. Available for summer 2026.",
    supervisor: "Emily Zhang (PhD Candidate)",
    deadline: "April 1, 2026",
    email: "ezhang@university.edu",
  },
  {
    title: "Postdoctoral Researcher: Human-Robot Interaction",
    type: "upcoming",
    projectType: "Postdoc",
    description: "Seeking a postdoctoral researcher to lead our new NSF-funded project on intuitive human-robot collaboration. The position involves developing shared autonomy systems and conducting user studies.",
    skills: ["HRI Research", "User Studies", "Machine Learning", "Robotics"],
    eligibility: "PhD in Robotics, HCI, or related field. Publication record in top venues.",
    supervisor: "Dr. Michael Rodriguez",
    startDate: "Fall 2026",
    email: "mrodriguez@university.edu",
  },
  {
    title: "PhD Position: Agricultural Robotics and Perception",
    type: "upcoming",
    projectType: "PhD",
    description: "Fully funded PhD position starting Fall 2026 on developing perception and navigation systems for agricultural robots. Partnership with local farms for field testing.",
    skills: ["Computer Vision", "Machine Learning", "Field Robotics", "Python"],
    eligibility: "BSc/MSc in relevant field. Interest in outdoor robotics.",
    supervisor: "Dr. Sarah Chen",
    startDate: "September 2026",
    email: "schen@university.edu",
  },
];

const currentOpportunities = opportunities.filter(o => o.type === "current");
const upcomingOpportunities = opportunities.filter(o => o.type === "upcoming");

const typeColors: Record<string, string> = {
  PhD: "bg-blue-100 text-blue-700",
  MSc: "bg-green-100 text-green-700",
  Undergrad: "bg-purple-100 text-purple-700",
  Postdoc: "bg-orange-100 text-orange-700",
};

const OpportunityCard = ({ opportunity }: { opportunity: Opportunity }) => (
  <div className="card-academic">
    <div className="flex flex-wrap items-center gap-3 mb-4">
      <span className={`px-3 py-1 rounded-full text-xs font-medium ${typeColors[opportunity.projectType]}`}>
        {opportunity.projectType}
      </span>
      {opportunity.deadline && (
        <span className="flex items-center gap-1 text-xs text-muted-foreground">
          <Clock className="w-3 h-3" /> Deadline: {opportunity.deadline}
        </span>
      )}
      {opportunity.startDate && (
        <span className="flex items-center gap-1 text-xs text-muted-foreground">
          <Calendar className="w-3 h-3" /> Starts: {opportunity.startDate}
        </span>
      )}
    </div>
    
    <h3 className="font-serif text-xl font-semibold text-foreground mb-3">
      {opportunity.title}
    </h3>
    
    <p className="text-muted-foreground text-sm mb-4 leading-relaxed">
      {opportunity.description}
    </p>
    
    <div className="space-y-3 mb-5">
      <div>
        <span className="text-xs font-semibold text-foreground uppercase tracking-wider">Required Skills</span>
        <div className="flex flex-wrap gap-2 mt-2">
          {opportunity.skills.map((skill, i) => (
            <span key={i} className="badge-research">{skill}</span>
          ))}
        </div>
      </div>
      
      <div>
        <span className="text-xs font-semibold text-foreground uppercase tracking-wider">Eligibility</span>
        <p className="text-sm text-muted-foreground mt-1">{opportunity.eligibility}</p>
      </div>
      
      <div className="flex items-center gap-2 text-sm">
        <Users className="w-4 h-4 text-accent" />
        <span className="text-muted-foreground">Supervisor:</span>
        <span className="font-medium text-foreground">{opportunity.supervisor}</span>
      </div>
    </div>
    
    <a 
      href={`mailto:${opportunity.email}?subject=Interest in: ${opportunity.title}`}
      className="btn-accent inline-flex items-center gap-2 text-sm"
    >
      <Mail className="w-4 h-4" /> Apply / Contact Supervisor
    </a>
  </div>
);

const Opportunities = () => {
  return (
    <Layout>
      {/* Header */}
      <section className="bg-primary py-16 md:py-20">
        <div className="container-narrow">
          <h1 className="font-serif text-4xl md:text-5xl font-bold text-primary-foreground mb-4 animate-fade-up">
            Research Opportunities
          </h1>
          <p className="text-primary-foreground/80 text-lg max-w-2xl animate-fade-up delay-100">
            Join our team and contribute to cutting-edge research in robotics and intelligent systems. 
            We offer positions at all levels.
          </p>
        </div>
      </section>

      {/* Current Opportunities */}
      <section className="section-padding">
        <div className="container-narrow">
          <div className="flex items-center gap-3 mb-8">
            <div className="w-3 h-3 rounded-full bg-green-500 animate-pulse" />
            <h2 className="font-serif text-2xl md:text-3xl font-bold text-foreground">
              Current Openings
            </h2>
          </div>
          
          <div className="grid md:grid-cols-2 gap-6 mb-16">
            {currentOpportunities.map((opportunity, index) => (
              <div 
                key={index}
                className="animate-fade-up"
                style={{ animationDelay: `${index * 100}ms` }}
              >
                <OpportunityCard opportunity={opportunity} />
              </div>
            ))}
          </div>

          {/* Upcoming Opportunities */}
          <div className="flex items-center gap-3 mb-8">
            <Calendar className="w-5 h-5 text-accent" />
            <h2 className="font-serif text-2xl md:text-3xl font-bold text-foreground">
              Upcoming Opportunities
            </h2>
          </div>
          
          <div className="grid md:grid-cols-2 gap-6 mb-16">
            {upcomingOpportunities.map((opportunity, index) => (
              <div 
                key={index}
                className="animate-fade-up"
                style={{ animationDelay: `${index * 100}ms` }}
              >
                <OpportunityCard opportunity={opportunity} />
              </div>
            ))}
          </div>

          {/* General Application */}
          <div className="bg-section-alt rounded-2xl p-8 md:p-12 text-center">
            <GraduationCap className="w-12 h-12 text-accent mx-auto mb-4" />
            <h3 className="font-serif text-2xl font-bold text-foreground mb-3">
              Don't see a fit? Send us your CV
            </h3>
            <p className="text-muted-foreground max-w-xl mx-auto mb-6">
              We're always looking for talented and motivated individuals. If you're interested in 
              our research but don't see a specific opening, feel free to reach out.
            </p>
            <a 
              href="mailto:risr@university.edu?subject=General Research Inquiry"
              className="btn-primary inline-flex items-center gap-2"
            >
              Send General Inquiry <ArrowRight className="w-4 h-4" />
            </a>
          </div>
        </div>
      </section>
    </Layout>
  );
};

export default Opportunities;
