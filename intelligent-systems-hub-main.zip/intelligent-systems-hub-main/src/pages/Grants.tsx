import Layout from "@/components/layout/Layout";
import { Building2, Calendar, DollarSign, ExternalLink } from "lucide-react";

interface Grant {
  title: string;
  agency: string;
  duration: string;
  value?: string;
  description: string;
  status: "active" | "completed";
  link?: string;
}

interface Partner {
  name: string;
  logo: string;
  type: "industry" | "academic";
}

const activeGrants: Grant[] = [
  {
    title: "Human-Robot Collaborative Assembly Systems",
    agency: "National Science Foundation (NSF)",
    duration: "2024 - 2027",
    value: "$850,000",
    description: "Developing shared autonomy frameworks and adaptive assistance systems for human-robot collaboration in manufacturing environments.",
    status: "active",
    link: "#",
  },
  {
    title: "Autonomous Navigation for Agricultural Robotics",
    agency: "USDA National Institute of Food and Agriculture",
    duration: "2024 - 2026",
    value: "$420,000",
    description: "Creating robust perception and navigation systems for autonomous agricultural robots operating in unstructured outdoor environments.",
    status: "active",
  },
  {
    title: "Scalable Multi-Robot Coordination",
    agency: "DARPA",
    duration: "2025 - 2028",
    value: "$1,200,000",
    description: "Fundamental research on coordination algorithms for large-scale heterogeneous robot teams in dynamic environments.",
    status: "active",
    link: "#",
  },
  {
    title: "Tactile Sensing for Dexterous Manipulation",
    agency: "Department of Energy (DOE)",
    duration: "2023 - 2026",
    value: "$380,000",
    description: "Developing next-generation tactile sensors and learning algorithms for robotic manipulation in nuclear decommissioning applications.",
    status: "active",
  },
];

const completedGrants: Grant[] = [
  {
    title: "Deep Reinforcement Learning for Robotic Control",
    agency: "National Science Foundation (NSF)",
    duration: "2020 - 2024",
    value: "$650,000",
    description: "Investigated sample-efficient deep RL algorithms for learning complex robotic skills with minimal human supervision.",
    status: "completed",
  },
  {
    title: "Semantic SLAM for Indoor Mobile Robots",
    agency: "Office of Naval Research (ONR)",
    duration: "2021 - 2024",
    value: "$520,000",
    description: "Developed semantic mapping and localization systems enabling robots to understand and navigate indoor environments.",
    status: "completed",
  },
  {
    title: "Sim-to-Real Transfer for Manipulation",
    agency: "Google Faculty Research Award",
    duration: "2022 - 2024",
    value: "$150,000",
    description: "Researched domain randomization and adaptation techniques for transferring manipulation skills from simulation to real robots.",
    status: "completed",
  },
];

const partners: Partner[] = [
  { name: "Boston Dynamics", logo: "https://images.unsplash.com/photo-1488590528505-98d2b5aba04b?w=200&h=100&fit=crop", type: "industry" },
  { name: "Nvidia Research", logo: "https://images.unsplash.com/photo-1518770660439-4636190af475?w=200&h=100&fit=crop", type: "industry" },
  { name: "Amazon Robotics", logo: "https://images.unsplash.com/photo-1461749280684-dccba630e2f6?w=200&h=100&fit=crop", type: "industry" },
  { name: "Toyota Research Institute", logo: "https://images.unsplash.com/photo-1486312338219-ce68d2c6f44d?w=200&h=100&fit=crop", type: "industry" },
  { name: "MIT CSAIL", logo: "https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?w=200&h=100&fit=crop", type: "academic" },
  { name: "Stanford AI Lab", logo: "https://images.unsplash.com/photo-1485827404703-89b55fcc595e?w=200&h=100&fit=crop", type: "academic" },
];

const GrantCard = ({ grant }: { grant: Grant }) => (
  <div className="card-academic">
    <div className="flex flex-wrap items-center gap-3 mb-4">
      <span className={`px-3 py-1 rounded-full text-xs font-medium ${
        grant.status === "active" 
          ? "bg-green-100 text-green-700" 
          : "bg-gray-100 text-gray-600"
      }`}>
        {grant.status === "active" ? "Active" : "Completed"}
      </span>
      <span className="flex items-center gap-1 text-xs text-muted-foreground">
        <Calendar className="w-3 h-3" /> {grant.duration}
      </span>
      {grant.value && (
        <span className="flex items-center gap-1 text-xs text-accent font-medium">
          <DollarSign className="w-3 h-3" /> {grant.value}
        </span>
      )}
    </div>
    
    <h3 className="font-serif text-xl font-semibold text-foreground mb-2">
      {grant.title}
    </h3>
    
    <div className="flex items-center gap-2 mb-3">
      <Building2 className="w-4 h-4 text-accent" />
      <span className="text-sm font-medium text-accent">{grant.agency}</span>
    </div>
    
    <p className="text-muted-foreground text-sm leading-relaxed">
      {grant.description}
    </p>
    
    {grant.link && (
      <a href={grant.link} className="inline-flex items-center gap-1 text-sm text-accent hover:underline mt-4">
        View Project <ExternalLink className="w-3 h-3" />
      </a>
    )}
  </div>
);

const Grants = () => {
  const totalFunding = activeGrants.reduce((sum, grant) => {
    const value = grant.value?.replace(/[^0-9]/g, '') || '0';
    return sum + parseInt(value);
  }, 0);

  return (
    <Layout>
      {/* Header */}
      <section className="bg-primary py-16 md:py-20">
        <div className="container-narrow">
          <h1 className="font-serif text-4xl md:text-5xl font-bold text-primary-foreground mb-4 animate-fade-up">
            Grants & Funding
          </h1>
          <p className="text-primary-foreground/80 text-lg max-w-2xl animate-fade-up delay-100">
            Our research is supported by federal agencies, industry partners, and foundations. 
            Total active funding exceeds ${(totalFunding / 1000000).toFixed(1)}M.
          </p>
        </div>
      </section>

      {/* Active Grants */}
      <section className="section-padding">
        <div className="container-narrow">
          <h2 className="font-serif text-2xl md:text-3xl font-bold text-foreground mb-8 flex items-center gap-3">
            <span className="w-3 h-3 rounded-full bg-green-500" />
            Active Grants
          </h2>
          
          <div className="grid md:grid-cols-2 gap-6 mb-16">
            {activeGrants.map((grant, index) => (
              <div 
                key={index}
                className="animate-fade-up"
                style={{ animationDelay: `${index * 100}ms` }}
              >
                <GrantCard grant={grant} />
              </div>
            ))}
          </div>

          {/* Completed Grants */}
          <h2 className="font-serif text-2xl md:text-3xl font-bold text-foreground mb-8">
            Completed Grants
          </h2>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mb-16">
            {completedGrants.map((grant, index) => (
              <div 
                key={index}
                className="animate-fade-up"
                style={{ animationDelay: `${index * 100}ms` }}
              >
                <GrantCard grant={grant} />
              </div>
            ))}
          </div>

          {/* Industry Partners */}
          <h2 className="font-serif text-2xl md:text-3xl font-bold text-foreground mb-8">
            Industry & Academic Partners
          </h2>
          
          <div className="bg-section-alt rounded-2xl p-8">
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-6">
              {partners.map((partner, index) => (
                <div 
                  key={index}
                  className="bg-background rounded-xl p-4 flex flex-col items-center justify-center text-center hover:shadow-md transition-shadow"
                >
                  <div className="w-16 h-16 rounded-lg bg-muted mb-3 overflow-hidden">
                    <img 
                      src={partner.logo} 
                      alt={partner.name}
                      className="w-full h-full object-cover opacity-70"
                    />
                  </div>
                  <span className="text-xs font-medium text-foreground">{partner.name}</span>
                  <span className="text-xs text-muted-foreground capitalize">{partner.type}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>
    </Layout>
  );
};

export default Grants;
