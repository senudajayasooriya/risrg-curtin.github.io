import Layout from "@/components/layout/Layout";
import { Mail, Linkedin, GraduationCap } from "lucide-react";

interface Member {
  name: string;
  role: string;
  interests: string;
  image: string;
  email: string;
  linkedin?: string;
  scholar?: string;
}

const faculty: Member[] = [
  {
    name: "Dr. Sarah Chen",
    role: "Principal Investigator",
    interests: "Autonomous Navigation, Machine Learning, Sensor Fusion",
    image: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400&h=400&fit=crop&crop=face",
    email: "schen@university.edu",
    linkedin: "#",
    scholar: "#",
  },
  {
    name: "Dr. Michael Rodriguez",
    role: "Co-Principal Investigator",
    interests: "Human-Robot Interaction, Control Systems, Manipulation",
    image: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=400&h=400&fit=crop&crop=face",
    email: "mrodriguez@university.edu",
    linkedin: "#",
    scholar: "#",
  },
];

const phdStudents: Member[] = [
  {
    name: "Emily Zhang",
    role: "PhD Candidate (4th Year)",
    interests: "Semantic SLAM, Computer Vision, Deep Learning",
    image: "https://images.unsplash.com/photo-1580489944761-15a19d654956?w=400&h=400&fit=crop&crop=face",
    email: "ezhang@university.edu",
    linkedin: "#",
  },
  {
    name: "James Wilson",
    role: "PhD Student (3rd Year)",
    interests: "Tactile Sensing, Grasping, Reinforcement Learning",
    image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&h=400&fit=crop&crop=face",
    email: "jwilson@university.edu",
    linkedin: "#",
  },
  {
    name: "Alex Kumar",
    role: "PhD Student (2nd Year)",
    interests: "Multi-Robot Systems, Coordination, Transfer Learning",
    image: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=400&h=400&fit=crop&crop=face",
    email: "akumar@university.edu",
  },
];

const mastersStudents: Member[] = [
  {
    name: "Lisa Park",
    role: "MSc Student",
    interests: "Agricultural Robotics, Visual Odometry",
    image: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=400&h=400&fit=crop&crop=face",
    email: "lpark@university.edu",
  },
  {
    name: "David Chen",
    role: "MSc Student",
    interests: "Motion Planning, Optimization",
    image: "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=400&h=400&fit=crop&crop=face",
    email: "dchen@university.edu",
  },
];

const undergrads: Member[] = [
  {
    name: "Sophie Martinez",
    role: "Undergraduate Researcher",
    interests: "Computer Vision, ROS Development",
    image: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=400&h=400&fit=crop&crop=face",
    email: "smartinez@university.edu",
  },
  {
    name: "Tom Anderson",
    role: "Undergraduate Researcher",
    interests: "Embedded Systems, Sensor Integration",
    image: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=400&h=400&fit=crop&crop=face",
    email: "tanderson@university.edu",
  },
];

const alumni: Member[] = [
  {
    name: "Dr. Rachel Kim",
    role: "PhD 2024 → Nvidia Research",
    interests: "Sim-to-Real Transfer, Robotics Simulation",
    image: "https://images.unsplash.com/photo-1487412720507-e7ab37603c6f?w=400&h=400&fit=crop&crop=face",
    email: "rkim@nvidia.com",
    linkedin: "#",
  },
  {
    name: "Dr. Marcus Johnson",
    role: "PhD 2023 → Boston Dynamics",
    interests: "Legged Locomotion, Dynamic Control",
    image: "https://images.unsplash.com/photo-1463453091185-61582044d556?w=400&h=400&fit=crop&crop=face",
    email: "mjohnson@bostondynamics.com",
    linkedin: "#",
  },
];

const MemberCard = ({ member }: { member: Member }) => (
  <div className="member-card">
    <div className="aspect-square overflow-hidden">
      <img 
        src={member.image} 
        alt={member.name}
        className="w-full h-full object-cover transition-transform duration-300 hover:scale-105"
      />
    </div>
    <div className="p-5">
      <h3 className="font-serif text-lg font-semibold text-foreground mb-1">{member.name}</h3>
      <p className="text-accent text-sm font-medium mb-2">{member.role}</p>
      <p className="text-muted-foreground text-sm mb-4">{member.interests}</p>
      <div className="flex gap-3">
        <a href={`mailto:${member.email}`} className="text-muted-foreground hover:text-accent transition-colors">
          <Mail className="w-5 h-5" />
        </a>
        {member.linkedin && (
          <a href={member.linkedin} className="text-muted-foreground hover:text-accent transition-colors">
            <Linkedin className="w-5 h-5" />
          </a>
        )}
        {member.scholar && (
          <a href={member.scholar} className="text-muted-foreground hover:text-accent transition-colors">
            <GraduationCap className="w-5 h-5" />
          </a>
        )}
      </div>
    </div>
  </div>
);

const MemberSection = ({ title, members }: { title: string; members: Member[] }) => (
  <div className="mb-16">
    <h2 className="font-serif text-2xl font-bold text-foreground mb-8 pb-3 border-b border-border">
      {title}
    </h2>
    <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
      {members.map((member, index) => (
        <div 
          key={index} 
          className="animate-fade-up"
          style={{ animationDelay: `${index * 100}ms` }}
        >
          <MemberCard member={member} />
        </div>
      ))}
    </div>
  </div>
);

const Members = () => {
  return (
    <Layout>
      {/* Header */}
      <section className="bg-primary py-16 md:py-20">
        <div className="container-narrow">
          <h1 className="font-serif text-4xl md:text-5xl font-bold text-primary-foreground mb-4 animate-fade-up">
            Our Team
          </h1>
          <p className="text-primary-foreground/80 text-lg max-w-2xl animate-fade-up delay-100">
            Meet the researchers, students, and alumni who make our work possible. 
            We're a diverse team united by our passion for robotics and AI.
          </p>
        </div>
      </section>

      {/* Members */}
      <section className="section-padding">
        <div className="container-narrow">
          <MemberSection title="Faculty & Principal Investigators" members={faculty} />
          <MemberSection title="PhD Students" members={phdStudents} />
          <MemberSection title="Masters Students" members={mastersStudents} />
          <MemberSection title="Undergraduate Researchers" members={undergrads} />
          <MemberSection title="Alumni" members={alumni} />
        </div>
      </section>
    </Layout>
  );
};

export default Members;
