import { Link } from "react-router-dom";
import Layout from "@/components/layout/Layout";
import { Bot, Cpu, Brain, Cog, ArrowRight, BookOpen, Users, Calendar } from "lucide-react";
import heroImage from "@/assets/hero-robotics.jpg";

const researchThemes = [
  {
    icon: Bot,
    title: "Autonomous Robotics",
    description: "Developing self-navigating robots for industrial, medical, and exploration applications.",
  },
  {
    icon: Brain,
    title: "Machine Learning & AI",
    description: "Deep learning architectures for perception, decision-making, and adaptive control systems.",
  },
  {
    icon: Cpu,
    title: "Intelligent Systems",
    description: "Smart systems that learn, adapt, and interact naturally with humans and environments.",
  },
  {
    icon: Cog,
    title: "Control Systems",
    description: "Advanced control algorithms for precise manipulation and dynamic stability.",
  },
];

const highlights = [
  {
    type: "Publication",
    title: "Adaptive Grasping with Tactile Feedback",
    venue: "IEEE Robotics and Automation Letters, 2026",
    link: "/research",
  },
  {
    type: "Project",
    title: "Human-Robot Collaborative Assembly",
    venue: "NSF Grant • 2024-2027",
    link: "/grants",
  },
  {
    type: "Award",
    title: "Best Paper Award at ICRA 2025",
    venue: "International Conference on Robotics and Automation",
    link: "/research",
  },
];

const stats = [
  { value: "50+", label: "Publications" },
  { value: "$4.2M", label: "Research Funding" },
  { value: "25", label: "Team Members" },
  { value: "12", label: "Industry Partners" },
];

const Index = () => {
  return (
    <Layout>
      {/* Hero Section */}
      <section className="relative min-h-[70vh] flex items-center">
        <div 
          className="absolute inset-0 z-0"
          style={{
            backgroundImage: `url(${heroImage})`,
            backgroundSize: 'cover',
            backgroundPosition: 'center',
          }}
        >
          <div className="absolute inset-0 bg-gradient-to-r from-primary/95 via-primary/80 to-primary/60" />
        </div>
        
        <div className="container-narrow relative z-10 py-20">
          <div className="max-w-2xl animate-fade-up">
            <span className="badge-research mb-4 inline-block bg-accent/20 text-accent-foreground border border-accent/30">
              University Research Excellence
            </span>
            <h1 className="font-serif text-4xl md:text-5xl lg:text-6xl font-bold text-primary-foreground mb-6 leading-tight">
              Robotics & Intelligent Systems Research Group
            </h1>
            <p className="text-lg md:text-xl text-primary-foreground/80 mb-8 leading-relaxed">
              Pioneering the future of autonomous systems, artificial intelligence, 
              and human-robot interaction through cutting-edge research and innovation.
            </p>
            <div className="flex flex-wrap gap-4">
              <Link to="/research" className="btn-accent inline-flex items-center gap-2">
                Explore Research <ArrowRight className="w-4 h-4" />
              </Link>
              <Link to="/opportunities" className="btn-outline border-primary-foreground text-primary-foreground hover:bg-primary-foreground hover:text-primary">
                Join Our Team
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="bg-accent py-8">
        <div className="container-narrow">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
            {stats.map((stat, index) => (
              <div key={index} className="animate-fade-up" style={{ animationDelay: `${index * 100}ms` }}>
                <div className="text-3xl md:text-4xl font-bold text-accent-foreground">{stat.value}</div>
                <div className="text-sm text-accent-foreground/80">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Research Themes */}
      <section className="section-padding">
        <div className="container-narrow">
          <div className="text-center mb-12">
            <h2 className="font-serif text-3xl md:text-4xl font-bold text-foreground mb-4">
              Research Focus Areas
            </h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Our interdisciplinary team tackles fundamental challenges across 
              robotics, AI, and intelligent systems.
            </p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {researchThemes.map((theme, index) => (
              <div 
                key={index} 
                className="card-academic text-center group animate-fade-up"
                style={{ animationDelay: `${index * 100}ms` }}
              >
                <div className="w-14 h-14 mx-auto mb-4 rounded-xl bg-accent/10 flex items-center justify-center group-hover:bg-accent group-hover:scale-110 transition-all duration-300">
                  <theme.icon className="w-7 h-7 text-accent group-hover:text-accent-foreground" />
                </div>
                <h3 className="font-serif text-xl font-semibold mb-2">{theme.title}</h3>
                <p className="text-muted-foreground text-sm">{theme.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Highlights Section */}
      <section className="section-padding section-alt">
        <div className="container-narrow">
          <div className="flex flex-col md:flex-row md:items-end md:justify-between mb-12">
            <div>
              <h2 className="font-serif text-3xl md:text-4xl font-bold text-foreground mb-2">
                Recent Highlights
              </h2>
              <p className="text-muted-foreground">
                Latest achievements from our research group
              </p>
            </div>
            <Link to="/research" className="text-accent font-medium flex items-center gap-1 mt-4 md:mt-0 hover:gap-2 transition-all">
              View All Research <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
          <div className="grid md:grid-cols-3 gap-6">
            {highlights.map((item, index) => (
              <Link 
                key={index} 
                to={item.link}
                className="card-academic group animate-fade-up"
                style={{ animationDelay: `${index * 100}ms` }}
              >
                <span className="badge-research mb-3">{item.type}</span>
                <h3 className="font-serif text-lg font-semibold mb-2 group-hover:text-accent transition-colors">
                  {item.title}
                </h3>
                <p className="text-muted-foreground text-sm">{item.venue}</p>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Quick Links */}
      <section className="section-padding">
        <div className="container-narrow">
          <div className="grid md:grid-cols-3 gap-8">
            <Link to="/research" className="flex items-start gap-4 p-6 rounded-xl border border-border hover:border-accent/50 hover:shadow-lg transition-all group">
              <div className="w-12 h-12 rounded-lg bg-accent/10 flex items-center justify-center shrink-0 group-hover:bg-accent transition-colors">
                <BookOpen className="w-6 h-6 text-accent group-hover:text-accent-foreground" />
              </div>
              <div>
                <h3 className="font-serif text-lg font-semibold mb-1 group-hover:text-accent transition-colors">Publications</h3>
                <p className="text-muted-foreground text-sm">Browse our research papers organized by year</p>
              </div>
            </Link>
            <Link to="/members" className="flex items-start gap-4 p-6 rounded-xl border border-border hover:border-accent/50 hover:shadow-lg transition-all group">
              <div className="w-12 h-12 rounded-lg bg-accent/10 flex items-center justify-center shrink-0 group-hover:bg-accent transition-colors">
                <Users className="w-6 h-6 text-accent group-hover:text-accent-foreground" />
              </div>
              <div>
                <h3 className="font-serif text-lg font-semibold mb-1 group-hover:text-accent transition-colors">Our Team</h3>
                <p className="text-muted-foreground text-sm">Meet our faculty, students, and alumni</p>
              </div>
            </Link>
            <Link to="/opportunities" className="flex items-start gap-4 p-6 rounded-xl border border-border hover:border-accent/50 hover:shadow-lg transition-all group">
              <div className="w-12 h-12 rounded-lg bg-accent/10 flex items-center justify-center shrink-0 group-hover:bg-accent transition-colors">
                <Calendar className="w-6 h-6 text-accent group-hover:text-accent-foreground" />
              </div>
              <div>
                <h3 className="font-serif text-lg font-semibold mb-1 group-hover:text-accent transition-colors">Opportunities</h3>
                <p className="text-muted-foreground text-sm">Current openings for researchers</p>
              </div>
            </Link>
          </div>
        </div>
      </section>
    </Layout>
  );
};

export default Index;
